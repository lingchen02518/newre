package com.example.yk_study.controller;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.yk_study.dto.userDto;
import com.example.yk_study.mapper.UserMapper;
import com.example.yk_study.po.userpo;
import com.example.yk_study.service.IUserService;
import com.example.yk_study.service.PageService;
import com.example.yk_study.service.RedisService;
import com.example.yk_study.service.impl.RedisServiceImpl;
import lombok.RequiredArgsConstructor;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import cn.hutool.*;

@RequestMapping("/users")
@RestController
@RequiredArgsConstructor

public class UserController {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private IUserService service;
    @Autowired
    private RedisService redisService;
    @Autowired
    private RedisTemplate redisTemplate;
    @PostMapping("/Addusers")
    public void Addusers(@RequestBody List<userDto> users){
        /*System.out.println(users.toString());*/
        redisService.saveDataToRedis(users);
        /*service.saveBatch(users);*/
    }


    @Autowired
    private PageService pageService;
    @GetMapping("/selectByPage")
    public IPage<userpo> selectByPage(@RequestParam("current") int current,
                                      @RequestParam("size") int size){
        Page<userpo> p = new Page<>(current,size);
        QueryWrapper<userpo> userpoQueryWrapper = new QueryWrapper<>();
        QueryWrapper<userpo> select = userpoQueryWrapper.select("id", "name", "age")
                                                        .eq("id",2);



        return pageService.page(p);
    }
    @GetMapping("/selectByIds")
    public List<userpo> getDataByIds(@RequestBody List<Long> ids){
        return redisService.getDataFromRedis(ids);
    }
}

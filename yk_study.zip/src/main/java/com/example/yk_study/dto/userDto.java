package com.example.yk_study.dto;

import lombok.Data;

@Data
public class userDto {
    private Long id;
    private String name;
    private Long age;
    private String email;
}

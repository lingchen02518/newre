package com.example.yk_study.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.yk_study.po.userpo;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 虎哥
 * @since 2024-03-04
 */
public interface IUserService extends IService<userpo> {

}
